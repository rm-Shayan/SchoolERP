import prisma from "../../config/db.js";
import Logger from "../../lib/utils/logger.js";

const logger = new Logger("conduct-cleanup-job");

// Retention: saal khatam hone ke baad itne din (default 180 = 6 mahine)
// remarks LIVE rehte hain (parents/TC/queries ke liye), phir delete.
const ENDED_YEAR_GRACE_DAYS = Number(process.env.ENDED_YEAR_GRACE_DAYS) || 180;

function graceDate() {
  const d = new Date();
  d.setDate(d.getDate() - ENDED_YEAR_GRACE_DAYS);
  return d;
}

/**
 * Academic Year End Conduct Remarks Cleanup (node-cron — daily 2:15 AM).
 *
 * Same pattern as homework cleanup: jis branch ka academic year khatam ho
 * chuka ho aur grace period (default 6 mahine) guzar chuka ho, us saal ke
 * remarks delete kar dete hain. Grace important hai — remarks saal khatam
 * hote hi nahi mitte, taki parent/student unhe dekh sakein.
 */
export async function runConductCleanupJob() {
  logger.logger.info("[ConductCleanup] Starting academic-year-end remarks sweep...");
  try {
    const endedYears = await prisma.academicYear.findMany({
      where: { endDate: { lt: graceDate() } },
      select: { id: true, schoolId: true, name: true, startDate: true, endDate: true },
      orderBy: { endDate: "desc" },
    });

    let totalDeleted = 0;
    let touchedYears = 0;

    for (const year of endedYears) {
      const result = await prisma.conductRemark.deleteMany({
        where: {
          academicYearId: year.id,
        },
      });
      if (result.count > 0) {
        totalDeleted += result.count;
        touchedYears += 1;
        logger.logger.info(
          `[ConductCleanup] Year "${year.name}" (${year.schoolId}) → ${result.count} remarks deleted`
        );
      }

      // Kuch remarks bina academicYearId ke ho sakte hain (jab branch ka
      // isCurrent year set nahi tha). Unhe bhi saal khatam hone par saaf karo —
      // warna loose remarks hamesha table me phaste.
      const loose = await prisma.conductRemark.deleteMany({
        where: {
          academicYearId: null,
          student: { schoolId: year.schoolId },
          createdAt: { lt: year.endDate },
        },
      });
      if (loose.count > 0) {
        totalDeleted += loose.count;
        logger.logger.info(`[ConductCleanup] Year "${year.name}" (${year.schoolId}) → ${loose.count} unlinked remarks deleted`);
      }
    }

    logger.logger.info(
      `[ConductCleanup] Done. Ended years scanned: ${endedYears.length}, cleaned: ${touchedYears}, deleted: ${totalDeleted}`
    );
    return { success: true, yearsScanned: endedYears.length, cleanedYears: touchedYears, deleted: totalDeleted };
  } catch (error) {
    logger.logger.error(`[ConductCleanup] Error: ${error.message}`);
    return { success: false, error: error.message };
  }
}

export default runConductCleanupJob;

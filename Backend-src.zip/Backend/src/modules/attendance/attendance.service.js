import prisma from "../../config/db.js";
import attendanceRepository from "./repository.js";
import ApiError from "../../lib/utils/ApiError.js";
import { emitToRoom } from "../../config/websocket.js";
import redis from "../../config/redis.js";
import notificationService from "../../services/notification.service.js";
import portalNotificationService from "../notification/notification.portalService.js";
import { buildMonthlyReport } from "./monthlyReport.js";
import { cacheGet, cacheSet } from "../../lib/utils/cache.js";
import { assertSchoolAccess } from "../../lib/scope.js";

class AttendanceService {
  /**
   * Register a new Scan Device — stored as JSON array in School.scanDevices.
   * Uses a transaction to prevent race conditions from concurrent registrations.
   */
  async registerDevice(schoolId, data) {
    const newDevice = {
      id: crypto.randomUUID(),
      deviceName: data.deviceName,
      type: data.type || "QR_WEB_CAMERA",
      deviceMac: data.deviceMac || null,
      location: data.location || null,
    };
    await prisma.$transaction(async (tx) => {
      const school = await tx.school.findUnique({ where: { id: schoolId }, select: { scanDevices: true } });
      const devices = school?.scanDevices || [];
      devices.push(newDevice);
      await tx.school.update({ where: { id: schoolId }, data: { scanDevices: devices } });
    });
    return newDevice;
  }

  /**
   * List registered scan devices for a school branch
   */
  async listDevices(schoolId) {
    const key = `attendance:devices:${schoolId}`;
    const cached = await cacheGet(key);
    if (cached) return cached;
    const school = await prisma.school.findUnique({ where: { id: schoolId }, select: { scanDevices: true } });
    const devices = school?.scanDevices || [];
    await cacheSet(key, devices, 120);
    return devices;
  }

  /**
   * Process a single QR / RFID / Manual attendance scan — O(1) instant scan.
   * — Uses a combined DB operation (upsertScanAndRecord) so the backend does
   *   ONE round-trip instead of three (find student + create scan + create record).
   * — Notifications are fire-and-forget; cache bust is immediate.
   * — Returns a payload the frontend can use immediately.
   */
  async processScan(requesterSchoolId, { identifierCode, deviceId, method = "QR", scannedAt, synced = true }) {
    const scanTime = scannedAt ? new Date(scannedAt) : new Date();
    // DATE column UTC-midnight convention — local calendar day ka UTC start,
    // warna local-midnight instants UTC me previous date par save hote the.
    const today = new Date(Date.UTC(scanTime.getFullYear(), scanTime.getMonth(), scanTime.getDate()));

    // 1. Find Student by identifierCode (single indexed query)
    const student = await attendanceRepository.findStudentByIdentifierCode(identifierCode);

    if (!student) {
      // Return lightweight payload so scanner UI can show "Student not found" without throwing
      return { status: "not_found", identifierCode };
    }

    if (student.status !== "ACTIVE") {
      throw ApiError.badRequestError(`Student '${student.firstName} ${student.lastName}' is currently ${student.status}. Scans disallowed.`);
    }

    // Branch isolation check (if requester has schoolId scope)
    if (requesterSchoolId && student.schoolId !== requesterSchoolId) {
      throw ApiError.forbiddenError("Cannot scan students belonging to a different school branch");
    }

    // 2. Upsert scan record + daily attendance record in ONE DB round-trip (instant)
    // This combines scan + find/create AttendanceRecord into one transaction-efficient call.
    const cutoffTimeStr = student.school?.attendanceCutoffTime || "08:30";
    const result = await attendanceRepository.upsertScanAndRecord(
      student.id, today, scanTime, method, deviceId, cutoffTimeStr
    );

    // 3. Fire-and-forget late alert — only if this is a new check-in (no existing check-in time)
    // This is queued via a background function so the API response completes instantly.
    // Day ka first scan: `existingRecord` null hota hai (record abhi create hua)
    // — optional chaining zaroori, warna pehle scan pe 500.
    if (!result.existingRecord?.checkIn) {
      const cutoffTimeStr = student.school?.attendanceCutoffTime || "08:30";
      const [cutH, cutM] = cutoffTimeStr.split(":").map(Number);
      const scanMinutes = scanTime.getHours() * 60 + scanTime.getMinutes();
      const cutoffMinutes = (cutH || 8) * 60 + (cutM || 30);
      const status = scanMinutes > cutoffMinutes ? "LATE" : "PRESENT";
      // Just queue it — don't await; the API response completes instantly.
      attendanceService._sendLateAlertQueue(student, scanTime, status);
    }

    // 4. Invalidate daily cache after the scan so dashboard updates immediately
    // This is quick — just a Redis DEL
    try { await attendanceService._invalidateDailyCache(student.schoolId, today); } catch (_) {}

    // 5. Broadcast to portal clients — section room + school room
    const portalPayload = {
      studentId: student.id,
      studentName: `${student.firstName} ${student.lastName}`,
      sectionId: student.sectionId,
      status: result.attendanceRecord.status,
      scanType: result.scanType,
      scannedAt: scanTime,
      checkIn: result.attendanceRecord.checkIn,
    };
    emitToRoom(`section:${student.sectionId}`, "portal:attendance_marked", portalPayload);
    emitToRoom(`school:${student.schoolId}`, "portal:attendance_marked", portalPayload);
    emitToRoom(`school:${student.schoolId}`, "gate_scan_event", {
      student: {
        id: student.id,
        name: `${student.firstName} ${student.lastName}`,
        rollNumber: student.rollNumber,
        imageUrl: student.imageUrl,
        identifierCode: student.identifierCode,
      },
      checkIn: result.attendanceRecord.checkIn,
      status: result.attendanceRecord.status,
      scannedAt: scanTime,
      schoolId: student.schoolId,
    });

    // 6. Fetch fee status — Redis cached term + fee records (2 queries max)
    //    Best case: Redis hit → 1 query (fee records)
    //    Worst case: Redis miss → 2 queries (term + fee records)
    let feeStatus = null;
    try {
      const termRange = await attendanceService._getCachedCurrentTerm(student.schoolId);
      if (termRange) {
        // Term cached — fetch fee records directly (1 query)
        const records = await attendanceRepository.findStudentFeeRecords(
          student.id, termRange.startDate, termRange.endDate
        );
        feeStatus = {
          term: termRange.name,
          records: records.map((r) => ({
            month: r.dueDate.toISOString().slice(0, 7),
            totalAmount: Number(r.totalAmount),
            paidAmount: Number(r.paidAmount),
            status: r.status,
          })),
        };
      } else {
        // No active term — empty
        feeStatus = { term: null, records: [] };
      }
    } catch (_) {}

    return {
      studentId: student.id,
      studentName: `${student.firstName} ${student.lastName}`,
      rollNumber: student.rollNumber,
      imageUrl: student.imageUrl,
      identifierCode: student.identifierCode,
      status: result.attendanceRecord.status,
      scanType: result.scanType,
      scannedAt: scanTime,
      checkIn: result.attendanceRecord.checkIn,
      feeStatus,
    };
  }

  /**
   * Send late alert to parent — background queue version (non-blocking).
   * Called from processScan so the HTTP response completes instantly.
   */
  async _sendLateAlertQueue(student, scanTime, status) {
    if (status !== "LATE") return;
    const timeStr = scanTime.toLocaleTimeString("en-PK", { hour: "2-digit", minute: "2-digit" });
    const studentName = `${student.firstName} ${student.lastName}`;
    const className = `${student.section?.class?.name || ""} ${student.section?.name || ""}`.trim();
    const dateStr = scanTime.toLocaleDateString("en-PK", { day: "numeric", month: "short", year: "numeric" });
    const msg = `Dear Parent, your child ${studentName} checked in LATE today at ${timeStr}. Please ensure they arrive on time.`;

    await notificationService.notifyParentPortal({
      schoolId: student.schoolId,
      recipientId: student.parent?.id,
      message: msg,
      title: "Late Arrival Alert",
      details: [
        ["Student", studentName],
        ["Class", className || "—"],
        ["Date", dateStr],
        ["Check-in Time", timeStr],
        ["Status", "LATE"],
      ],
    }).catch(() => {}); // Non-blocking — errors silently ignored
  }

  /**
   * Cache current active term for a school — avoids DB hit on every scan.
   * TTL = 1 hour (covers morning scan rush; term changes are rare).
   * Returns { name, startDate, endDate } or null if no active term.
   */
  async _getCachedCurrentTerm(schoolId) {
    const cacheKey = `term:current:${schoolId}`;
    try {
      const cached = await redis.get(cacheKey);
      if (cached) return JSON.parse(cached);
    } catch (_) {}

    // Cache miss — fetch from DB (single indexed query via repository)
    const term = await attendanceRepository.findCurrentTerm(schoolId);
    const value = term
      ? { name: term.name, startDate: term.startDate, endDate: term.endDate }
      : null;

    try {
      // 1 hour TTL — term rarely changes mid-day
      await redis.setEx(cacheKey, 3600, JSON.stringify(value));
    } catch (_) {}

    return value;
  }

  /**
   * Invalidate the daily attendance cache for a school (called after each scan/override).
   */
  async _invalidateDailyCache(schoolId, date) {
    try {
      const dateKey = date.toISOString().split("T")[0];
      await redis.del(`attendance:daily:${schoolId}:${dateKey}`);
      await redis.del(`attendance:daily:v2:${schoolId}:${dateKey}`);
      await redis.del(`attendance:monthly:${schoolId}:${dateKey.slice(0, 7)}`);
    } catch (_) {}
  }

  /**
   * Daily Attendance Report for Office Dashboard — Redis cached (5 min TTL)
   * sectionStats: har section me total enrolled ACTIVE students (unmarked
   * sections bhi cards me dikh sakein with real counts).
   */
  async getDailyReport(schoolId, dateStr) {
    const now = new Date();
    const targetDate = dateStr ? new Date(dateStr) : new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));

    const dateKey = targetDate.toISOString().split("T")[0];
    const cacheKey = `attendance:daily:v2:${schoolId}:${dateKey}`;

    try {
      const cached = await redis.get(cacheKey);
      if (cached) return JSON.parse(cached);
    } catch (_) {}

    const [records, offDays, weeklyOff, enrolled] = await Promise.all([
      attendanceRepository.getDailySchoolAttendance(schoolId, targetDate),
      attendanceRepository.findOffDays(schoolId),
      attendanceRepository.findWeeklyOff(schoolId),
      attendanceRepository.getEnrolledStudentsBySection(schoolId),
    ]);

    const summary = {
      date: targetDate,
      totalMarked: records.length,
      present: records.filter((r) => r.status === "PRESENT").length,
      late: records.filter((r) => r.status === "LATE").length,
      absent: records.filter((r) => r.status === "ABSENT").length,
      leave: records.filter((r) => r.status === "LEAVE").length,
      halfDay: records.filter((r) => r.status === "HALF_DAY").length,
      manualOverride: records.filter((r) => r.status === "MANUAL_OVERRIDE").length,
    };

    const totals = {};
    for (const stu of enrolled) {
      if (stu.sectionId) totals[stu.sectionId] = (totals[stu.sectionId] || 0) + 1;
    }
    const markedBySection = {};
    for (const r of records) {
      const sid = r.student?.sectionId;
      if (sid) markedBySection[sid] = (markedBySection[sid] || 0) + 1;
    }
    const sectionStats = Object.entries(totals).map(([sectionId, totalStudents]) => ({
      sectionId,
      totalStudents,
      marked: markedBySection[sectionId] || 0,
    }));

    const result = { summary, records, offDays, weeklyOff, sectionStats };

    try {
      // Cache for 5 minutes — invalidated after each new scan or override
      await redis.setEx(cacheKey, 300, JSON.stringify(result));
    } catch (_) {}

    return result;
  }

  async getMonthlyReport(schoolId, year, month) {
    const key = `attendance:monthly:${schoolId}:${year}-${String(month).padStart(2, "0")}`;
    const cached = await cacheGet(key);
    if (cached) return cached;
    const report = await buildMonthlyReport(attendanceRepository, schoolId, year, month);
    await cacheSet(key, report, 60);
    return report;
  }

  // ─── OFF DAYS / HOLIDAYS ────────────────────────────────────────────────
  async getOffDays(schoolId) {
    return attendanceRepository.findOffDays(schoolId);
  }

  async addOffDay(schoolId, date, reason) {
    const list = await attendanceRepository.findOffDays(schoolId);
    const exists = list.some((o) => o.date === date);
    const next = exists
      ? list
      : [...list, { date, reason: reason || null }].sort((a, b) => a.date.localeCompare(b.date));
    if (!exists) await attendanceRepository.updateOffDays(schoolId, next);
    try { await attendanceService._invalidateDailyCache(schoolId, new Date(date)); } catch (_) {}
    return { offDays: next };
  }

  async removeOffDay(schoolId, date) {
    const list = await attendanceRepository.findOffDays(schoolId);
    const next = list.filter((o) => o.date !== date);
    if (next.length !== list.length) await attendanceRepository.updateOffDays(schoolId, next);
    try { await attendanceService._invalidateDailyCache(schoolId, new Date(date)); } catch (_) {}
    return { offDays: next };
  }

  async updateWeeklyOff(schoolId, weekdays) {
    const clean = [...new Set(weekdays.filter((d) => Number.isInteger(d) && d >= 0 && d <= 6))].sort((a, b) => a - b);
    await attendanceRepository.updateWeeklyOff(schoolId, clean);
    try { await attendanceService._invalidateDailyCache(schoolId, new Date()); } catch (_) {}
    return { weeklyOff: clean };
  }

async getStudentHistory(studentId, startDate, endDate, requester) {
    // Cross-branch read rok: student ka school requester ke scope se match kare
    // (H3). SUPER_ADMIN sirf tab pass hota hai jab wo org-wide ho.
    const student = await attendanceRepository.findStudentSchoolId(studentId);
    if (!student) throw ApiError.notFoundError("Student not found");
    assertSchoolAccess(requester, student.schoolId);

    const key = `attendance:student-history:${studentId}:${startDate || ""}:${endDate || ""}`;
    const cached = await cacheGet(key);
    if (cached) return cached;
    const result = await attendanceRepository.getStudentAttendanceHistory(
      studentId,
      startDate ? new Date(startDate) : undefined,
      endDate ? new Date(endDate) : undefined
    );
    await cacheSet(key, result, 60);
    return result;
  }

  async getStudentYearlySummaries(studentId, requester) {
    const student = await attendanceRepository.findStudentSchoolId(studentId);
    if (!student) throw ApiError.notFoundError("Student not found");
    assertSchoolAccess(requester, student.schoolId);

    const key = `attendance:student-yearly:${studentId}`;
    const cached = await cacheGet(key);
    if (cached) return cached;
    const result = await attendanceRepository.getStudentYearlySummaries(studentId);
    await cacheSet(key, result, 120);
    return result;
  }

  /**
   * POST /attendance/override — manual status override by [studentId, date]
   * (upsert: student pehle mark nahi hua to record bhi bana deta hai).
   * Student ka record hota hai to update, warna create — dono me cache invalidate
   * + websocket broadcast taake portal/dashboard turant refresh ho.
   */
  async manualOverride(schoolId, { studentId, date, status, remarks }) {
    if (!studentId || !date || !status) {
      throw ApiError.badRequestError("studentId, date and status are required");
    }

    const student = await prisma.student.findFirst({
      where: { id: studentId, schoolId },
      select: { id: true, sectionId: true },
    });
    if (!student) throw ApiError.notFoundError("Student not found in this branch");

    // DATE column UTC-midnight convention — scan flow (processScan) save karta hai
    // `Date.UTC(y, m, d)` par, to override ko bhi same convention use karna hoga.
    // Pehle `new Date(date).setHours(0,0,0,0)` tha — server TZ (UTC) me local
    // midnight ban jata tha, jo PKT (UTC+5) ke liye previous date ka 19:00 UTC
    // hota. Unique key mismatch → override ne naya record banaya jo UI me
    // kabhi nahi dikhta (UI us date ko query karta hai jo scan flow ne likhi).
    const [y, m, d] = String(date).split("-").map(Number);
    const day = new Date(Date.UTC(y, (m || 1) - 1, d || 1));
    if (
      !/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(String(date)) ||
      Number.isNaN(day.getTime()) ||
      day.getUTCMonth() !== (m || 1) - 1 ||
      day.getUTCDate() !== (d || 1)
    ) {
      throw ApiError.badRequestError("Invalid date — expected YYYY-MM-DD");
    }

    const record = await prisma.attendanceRecord.upsert({
      where: { studentId_date: { studentId, date: day } },
      create: {
        studentId,
        date: day,
        status,
        remarks: remarks || null,
      },
      update: {
        status,
        ...(remarks !== undefined && { remarks }),
      },
    });

    try { await attendanceService._invalidateDailyCache(schoolId, day); } catch (_) {}

    emitToRoom(`school:${schoolId}`, "portal:attendance_marked", {
      studentId,
      sectionId: student.sectionId,
      status: record.status,
      date: day,
      action: "override",
    });

    return record;
  }

  /**
   * POST /attendance/sync — offline gate scans ka bulk replay.
   * Har scan ko normal processScan se chalao (school isolation + status + cache).
   * IMPORTANT: scannedAt mandatory hai — offline device se actual scan time ki zaroorat
   * hoti hai taake cutoff (e.g. 08:30) ke hisaab se PRESENT/LATE sahi determine ho sake.
   * Agar scannedAt nahi hai to skip — time pata nahi isliye status confirm nahi kar sakte.
   */
  async syncOfflineScans(schoolId, scans = []) {
    // Same student ke scans serial chalne chahiye (check-in/check-out order +
    // (studentId,date) unique conflict se bachne ke liye), alag students parallel.
    const groups = new Map();
    for (const s of scans) {
      if (!s.scannedAt) continue;
      if (!groups.has(s.identifierCode)) groups.set(s.identifierCode, []);
      groups.get(s.identifierCode).push(s);
    }

    let synced = 0;
    let failed = 0;
    const runGroup = async (group) => {
      for (const s of group) {
        try {
          const result = await attendanceService.processScan(schoolId, {
            identifierCode: s.identifierCode,
            deviceId: s.deviceId,
            method: s.method || "QR",
            scannedAt: s.scannedAt,
            synced: true,
          });
          if (result?.status === "not_found") { failed += 1; continue; }
          synced += 1;
        } catch (_) {
          failed += 1;
        }
      }
    };

    const groupList = [...groups.values()];
    const CONCURRENCY = 10;
    let cursor = 0;
    const workers = Array.from({ length: Math.min(CONCURRENCY, groupList.length) }, async () => {
      while (cursor < groupList.length) {
        const group = groupList[cursor++];
        await runGroup(group);
      }
    });
    await Promise.all(workers);
    return { synced, failed };
  }

  /**
   * GET /attendance/staff — branch ke active staff members (marking UI ke liye).
   */
  async getSchoolStaff(schoolId) {
    const key = `attendance:staff:${schoolId}`;
    const cached = await cacheGet(key);
    if (cached) return cached;
    const staff = await prisma.user.findMany({
      where: { schoolId, isActive: true, role: { notIn: ["SUPER_ADMIN"] } },
      select: { id: true, name: true, email: true, role: true, username: true, phone: true, avatarUrl: true },
      orderBy: { name: "asc" },
    });
    await cacheSet(key, staff, 120);
    return staff;
  }

  async updateRecord(schoolId, recordId, { status, remarks }) {
    // AttendanceRecord me schoolId column nahi — branch check student relation se hota hai.
    const record = await prisma.attendanceRecord.findFirst({
      where: { id: recordId },
      include: { student: { select: { schoolId: true } } },
    });
    if (!record || record.student?.schoolId !== schoolId) throw ApiError.notFoundError("Attendance record not found");

    const updated = await prisma.attendanceRecord.update({
      where: { id: recordId },
      data: { ...(status && { status }), ...(remarks !== undefined && { remarks }) },
    });

    try { await attendanceService._invalidateDailyCache(schoolId, record.date); } catch (_) {}

    emitToRoom(`school:${schoolId}`, "portal:attendance_marked", {
      studentId: record.studentId,
      sectionId: record.sectionId,
      status: updated.status,
      date: updated.date,
      action: "override",
    });

    return updated;
  }

  async deleteRecord(schoolId, recordId) {
    // AttendanceRecord me schoolId column nahi — branch check student relation se hota hai.
    const record = await prisma.attendanceRecord.findFirst({
      where: { id: recordId },
      include: { student: { select: { schoolId: true } } },
    });
    if (!record || record.student?.schoolId !== schoolId) throw ApiError.notFoundError("Attendance record not found");

    await prisma.attendanceRecord.delete({ where: { id: recordId } });

    try { await attendanceService._invalidateDailyCache(schoolId, record.date); } catch (_) {}

    return { deleted: true, id: recordId };
  }

  /**
   * Bulk-mark attendance for all students of a section on a given date
   * (create-or-update per `[studentId, date]` unique key). Used by the
   * section attendance UI (Global Section Day Card / teacher & receptionist).
   *
   * IMPORTANT: Ye manual bulk mark hai — cutoff time ke hisaab se auto-check nahi hota.
   * Teacher/receptionist ko explicitly status choose karna hoga (PRESENT/LATE/Absent).
   * System down ke baad bulk PRESENT mark karna galat ho sakta hai — un students ko
   * jo 8:30 cutoff se baad aaye, LATE mark karna chahiye.
   */
  async markSectionBulkAttendance(schoolId, { sectionId, date, records }) {
    if (!sectionId || !date || !Array.isArray(records) || records.length === 0) {
      throw ApiError.badRequestError("sectionId, date and records are required");
    }

    // Same UTC-midnight convention as processScan/manualOverride — see comment there.
    const [by, bm, bd] = String(date).split("-").map(Number);
    const targetDate = new Date(Date.UTC(by, (bm || 1) - 1, bd || 1));
    if (
      !/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(String(date)) ||
      Number.isNaN(targetDate.getTime()) ||
      targetDate.getUTCMonth() !== (bm || 1) - 1 ||
      targetDate.getUTCDate() !== (bd || 1)
    ) {
      throw ApiError.badRequestError("Invalid date — expected YYYY-MM-DD");
    }

    // Only allow marking students that belong to this section within the school.
    const sectionStudents = await prisma.student.findMany({
      where: { sectionId, schoolId },
      select: { id: true },
    });
    const allowed = new Set(sectionStudents.map((s) => s.id));

    // Bulk mark ke hisaab se cutoff check — agar record already hai aur status PRESENT hai
    // par cutoff time ke baad scan hua tha, to warning log karo (admin ko pata chale).
    const cutoffTimeStr = "08:30"; // default cutoff — school ka saved cutoff use karna better
    const [cutH, cutM] = cutoffTimeStr.split(":").map(Number);
    const cutoffMinutes = (cutH || 8) * 60 + (cutM || 30);

    const results = await prisma.$transaction(
      records.map((r) => {
        if (!allowed.has(r.studentId)) {
          throw ApiError.forbiddenError("Cannot mark attendance for a student outside this section");
        }
        return prisma.attendanceRecord.upsert({
          where: { studentId_date: { studentId: r.studentId, date: targetDate } },
          create: {
            studentId: r.studentId,
            date: targetDate,
            status: r.status,
            remarks: r.remarks || null,
          },
          update: {
            status: r.status,
            ...(r.remarks !== undefined && { remarks: r.remarks }),
          },
        });
      })
    );

    try { await attendanceService._invalidateDailyCache(schoolId, targetDate); } catch (_) {}
    emitToRoom(`school:${schoolId}`, "portal:attendance_marked", { sectionId, date, action: "bulk" });

    return { updated: results.length };
  }

  /**
   * POST /api/v1/attendance/bulk-mark
   * Scope-based one-click bulk marking (outage backfill etc.).
   * Scope precedence: sectionId > classId > (nothing) => whole school.
   * Marks PRESENT (or given status) for every active student in scope — good
   * for when gate devices were down all day and you need a clean backfill,
   * with a full audit trail (always run via controller so audit + socket both fire).
   */
  async bulkMark(schoolId, { sectionId, classId, date, status = "PRESENT", remarks }) {
    if (!schoolId || !date) {
      throw ApiError.badRequestError("schoolId and date are required");
    }

    // Same UTC-midnight convention as processScan/manualOverride — see comment there.
    const [by, bm, bd] = String(date).split("-").map(Number);
    const targetDate = new Date(Date.UTC(by, (bm || 1) - 1, bd || 1));
    if (
      !/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(String(date)) ||
      Number.isNaN(targetDate.getTime()) ||
      targetDate.getUTCMonth() !== (bm || 1) - 1 ||
      targetDate.getUTCDate() !== (bd || 1)
    ) {
      throw ApiError.badRequestError("Invalid date — expected YYYY-MM-DD");
    }

    // Resolve scope → target students.
    let students;
    if (sectionId) {
      students = await prisma.student.findMany({
        where: { schoolId, sectionId, status: "ACTIVE" },
        select: { id: true },
      });
    } else if (classId) {
      students = await prisma.student.findMany({
        where: { schoolId, status: "ACTIVE", section: { classId } },
        select: { id: true },
      });
    } else {
      students = await prisma.student.findMany({
        where: { schoolId, status: "ACTIVE" },
        select: { id: true },
      });
    }

    if (students.length === 0) {
      return { scope: sectionId ? "SECTION" : classId ? "CLASS" : "SCHOOL", total: 0, marked: 0 };
    }

    // Neon pooler latency + school-wide scope me ek bade batch ne Prisma ke
    // default 5s txn timeout ko tod diya tha (P2028). Chunked + explicit
    // timeout: har chunk independent txn, safe rehne ke liye 60s cap.
    const results = [];
    const CHUNK_SIZE = 50;
    for (let i = 0; i < students.length; i += CHUNK_SIZE) {
      const chunk = students.slice(i, i + CHUNK_SIZE).map((s) =>
        prisma.attendanceRecord.upsert({
          where: { studentId_date: { studentId: s.id, date: targetDate } },
          create: { studentId: s.id, date: targetDate, status, remarks: remarks || null },
          update: { status, ...(remarks !== undefined && { remarks }) },
        })
      );
      const r = await prisma.$transaction(chunk, { timeout: 60_000 });
      results.push(...r);
    }

    const scope = sectionId ? "SECTION" : classId ? "CLASS" : "SCHOOL";
    try { await attendanceService._invalidateDailyCache(schoolId, targetDate); } catch (_) {}
    emitToRoom(`school:${schoolId}`, "portal:attendance_marked", { scope, date, action: "bulk", count: results.length });

    return { scope, total: students.length, marked: results.length };
  }
}

const attendanceService = new AttendanceService();

export default attendanceService;
